var Program = Backbone.Model.extend({
  defaults: {
    id: null,
    title: "Sample Title",
    description: "Sample Description",
  }
});
